OpenPop.NET code repository
====

See our [project website](http://hpop.sourceforge.net/) for more information.

## Installing via NuGet
The easiest way to install OpenPop.NET is via [NuGet](https://www.nuget.org/packages/OpenPop.NET/).

In Visual Studio's [Package Manager Console](http://docs.nuget.org/docs/start-here/using-the-package-manager-console),
simply enter the following command:

    Install-Package OpenPop.NET

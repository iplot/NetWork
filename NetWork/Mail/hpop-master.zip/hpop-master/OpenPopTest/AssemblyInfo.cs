using System.Reflection;

[assembly: AssemblyTitle("OpenPop Test Application")]
[assembly: AssemblyDescription("OpenPop POP3 Test Application")]